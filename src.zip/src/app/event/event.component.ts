import { Component, OnInit } from '@angular/core';
import { eventService } from '../services/events.service';

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css']
})
export class EventComponent implements OnInit {

  constructor(private eventsService: eventService) { }
  events: any[] = [];

  ngOnInit(): void {
  }
  getEvents(): void {
    this.eventsService.getEvents()
      .subscribe(events => this.events = events);
  }
}


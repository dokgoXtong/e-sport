import { Component, OnInit } from '@angular/core';
import { shopService } from '../services/shop.service';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit {

  shops:any;

  constructor( private shopService : shopService) { }

  ngOnInit(): void {
    this.getshop();
  }
  getshop(): void {
    this.shopService.getListshop().subscribe(data => {
      console.log(data);
      this.shops = data;
      },
      err => console.log(err)
      );
      }}


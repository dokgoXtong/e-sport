
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class gamesService {
  getgames(id: number) {
    throw new Error('Method not implemented.');
  }

  constructor(private httpClient: HttpClient) {}

  getListGames(): Observable<any[]> {
    return this.httpClient.get<any[]>('http://localhost:8081/api/games');
  }

  getOnegames(id: number): Observable<any> {
    return this.httpClient.get<any>('http://localhost:8081/api/games/' + id);
  }
  getGamesByCategory(categoryId: number): Observable<any[]> {
    const url = `http://localhost:8081/api/games/category/${categoryId}`;
    return this.httpClient.get<any[]>(url);
  }
  postproduit(data: any): Observable<any> {
    return this.httpClient.post<any>(`${environment.apiUrl}/games/${environment}`, data);
  }

  updateproduit(data: any): Observable<any> {
    const {  idGame,name, image } = data;
    return this.httpClient.put<any>(
      `${environment.apiUrl}/games/${environment}`, 
      { 
        "idGame":idGame,
        "name": name,
        "image": image,
      }
    );
  }
  
  deletegames(id: number): Observable<any[]> {
    return this.httpClient.delete<any[]>(`${environment.apiUrl}/games/${environment}/${id}`);
  }

}

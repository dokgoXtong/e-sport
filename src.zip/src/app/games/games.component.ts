import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { gamesService } from '../services/games.service';
import { Observable, map } from 'rxjs';

@Component({
  selector: 'app-games',
  templateUrl: './games.component.html',
  styleUrls: ['./games.component.css']
})
export class GamesComponent implements OnInit {
  games: any[] = [];
  filteredGames: any[] = [];
  constructor(private gamesService: gamesService) { }

  ngOnInit(): void {
    this.getGames();
  }

  getGames(): void {
    this.gamesService.getListGames().subscribe(
      data => {
        console.log(data);
        this.games = data;
        this.filteredGames = this.games; // Initialize filteredGames with all games
      },
      err => console.log(err)
    );
  }

  filterGames(categoryId: number): void {
    this.gamesService.getGamesByCategory(categoryId)
      .subscribe(games => {
        this.games = games;
        this.filteredGames = this.games.filter((game: any) => game.category.idCategory === categoryId);
      });
  }
}
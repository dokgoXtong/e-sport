import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ShopComponent } from './shop/shop.component';
import {HttpClientModule } from '@angular/common/http';
import { GamesComponent } from './games/games.component';
import { EventComponent } from './event/event.component';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ShopComponent,
    GamesComponent,
    EventComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

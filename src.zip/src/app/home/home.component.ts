import { Component, OnInit } from '@angular/core';
import { gamesService } from '../services/games.service'; // Corrected import
import { shopService } from '../services/shop.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  gamess: any[] = [];
  shopss: any[] = [];

  constructor(private gamesService: gamesService , private shopService : shopService) { }

  ngOnInit(): void {
    this.getOneGames(1);
    this.getOneGames(2); 
    this.getOneGames(3); 
    this.getOneGames(5); 
    this.getOneGames(18); 
    this.getOneGames(19); 
  
  }

  getOneGames(id: number): void {
    this.gamesService.getOnegames(id).subscribe(
      data => {
        console.log(data);
        this.gamess.push(data); // Push each data object into the gamess array
      },
      err => console.log(err)
    );
  }
  getOneshop(id: number): void {
    this.shopService.getOneshop(id).subscribe(
      data => {
        console.log(data);
        this.gamess.push(data); // Push each data object into the gamess array
      },
      err => console.log(err)
    );
  }
}
